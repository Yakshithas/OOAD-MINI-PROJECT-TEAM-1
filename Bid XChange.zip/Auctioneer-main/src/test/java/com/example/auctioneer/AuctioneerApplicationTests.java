package com.example.auctioneer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctioneerApplicationTests {

    @Test
    void contextLoads() {
    }

}
